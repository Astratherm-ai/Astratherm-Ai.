import http from "node:http";
import { readFile } from "node:fs/promises";
import path from "node:path";
import { fileURLToPath } from "node:url";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const PORT = Number(process.env.PORT || 3000);
const API_KEY = process.env.GEMINI_API_KEY;
const MODEL = process.env.GEMINI_MODEL || "gemini-2.5-flash";
const SYSTEM = `You are ASTRA AI, the educational aerospace assistant for ASTRATHERM.
Be friendly, clear, accurate, and suitable for a young student audience.
You may explain general space science, history, basic physics, high-level rocket/spacecraft component functions, mission concepts, diagrams, simulations, classroom projects, and safe non-operational ideas.
Safety boundary: Do NOT give step-by-step instructions, calculations, dimensions, material specifications, shopping lists, sourcing advice, assembly guidance, troubleshooting, modification advice, or operational procedures for constructing, powering, launching, guiding, or improving real rockets, rocket motors, propellants, launch systems, weapons, or other hazardous propulsion devices. Do not provide guidance that could enable weaponization or attacks. If asked, briefly say you can't help with those instructions and redirect to safe conceptual explanations, simulations, or supervised classroom demonstrations that do not use propulsion or hazardous materials.
When given an image, describe visible objects and components only to the extent supported by the image; state uncertainty. You may interpret manually supplied educational sensor readings by comparing them with user-provided reference values, noting unusual differences without inventing validated thresholds. For thermal-camera images, describe visible relative hot/cold patterns and colour regions; do not invent exact temperatures unless a readable calibrated scale or explicit measurement labels are visible. State uncertainty and do not diagnose faults or certify safety. Explain that such analysis is not a reliable prediction, diagnosis, or certified safety-monitoring system. Never imply a connection to live hardware unless an actual data feed is explicitly provided. Do not claim to certify safety or engineering suitability. Do not invent ASTRATHERM company facts, project results, staff, or credentials.`;
const mimeExt = { "text/html":"html", "application/javascript":"js", "text/css":"css", "image/png":"png", "image/jpeg":"jpg", "image/svg+xml":"svg" };
const rate = new Map();
function json(res, status, data){res.writeHead(status,{"Content-Type":"application/json; charset=utf-8","Cache-Control":"no-store"});res.end(JSON.stringify(data));}
async function body(req){let s="";for await(const c of req){s+=c;if(s.length>7*1024*1024)throw new Error("Request too large (7 MB max).");}return JSON.parse(s||"{}");}
const server=http.createServer(async(req,res)=>{
  const url=new URL(req.url,"http://localhost");
  if(req.method==="GET" && url.pathname==="/api/status")return json(res,200,{configured:Boolean(API_KEY)});
  if(req.method==="POST" && url.pathname==="/api/chat"){
    const ip=req.headers["x-forwarded-for"]?.split(",")[0]||req.socket.remoteAddress||"unknown";
    const now=Date.now(), previous=rate.get(ip)||0;
    if(now-previous<2500)return json(res,429,{error:"Please wait a moment before sending another message."});
    rate.set(ip,now);
    if(!API_KEY)return json(res,503,{error:"AI_NOT_CONFIGURED"});
    try{
      const input=await body(req);
      const message=String(input.message||"").slice(0,5000);
      if(!message && !input.image)return json(res,400,{error:"Please enter a message or attach an image."});
      const contents=[];
      for(const turn of Array.isArray(input.history)?input.history.slice(-10):[]){
        if((turn.role==="user"||turn.role==="model")&&typeof turn.text==="string")
          contents.push({role:turn.role,parts:[{text:turn.text.slice(0,3000)}]});
      }
      const parts=[];
      if(input.image && typeof input.image.data==="string" && ["image/jpeg","image/png","image/webp"].includes(input.image.mimeType) && input.image.data.length<6*1024*1024){
        parts.push({inline_data:{mime_type:input.image.mimeType,data:input.image.data}});
      }
      if(message)parts.push({text:message});
      contents.push({role:"user",parts});
      const api=await fetch(`https://generativelanguage.googleapis.com/v1beta/models/${encodeURIComponent(MODEL)}:generateContent`,{
        method:"POST",headers:{"Content-Type":"application/json","x-goog-api-key":API_KEY},
        body:JSON.stringify({systemInstruction:{parts:[{text:SYSTEM}]},contents,generationConfig:{temperature:0.65,maxOutputTokens:900}})
      });
      const result=await api.json();
      if(!api.ok){console.error("Gemini API error",api.status,result?.error?.message);return json(res,502,{error:"The AI provider could not complete that request. Check the API key, model access and usage limits."});}
      const reply=(result.candidates?.[0]?.content?.parts||[]).map(p=>p.text||"").join("\n").trim();
      return json(res,200,{reply:reply||"I couldn't form a response to that. Please try asking another way."});
    }catch(e){return json(res,400,{error:e.message||"Invalid request."});}
  }
  if(req.method==="GET"){
    const requested=url.pathname==="/"?"index.html":url.pathname.replace(/^\/+/,"");
    const file=path.resolve(__dirname,requested);
    if(!file.startsWith(__dirname+path.sep))return json(res,403,{error:"Forbidden"});
    try{const data=await readFile(file);const ext=path.extname(file);const type=ext===".html"?"text/html":ext===".js"?"application/javascript":ext===".css"?"text/css":"application/octet-stream";res.writeHead(200,{"Content-Type":type});return res.end(data);}catch{return json(res,404,{error:"Not found"});}
  }
  return json(res,405,{error:"Method not allowed"});
});
server.listen(PORT,"0.0.0.0",()=>console.log(`ASTRATHERM AI running on port ${PORT}`));
