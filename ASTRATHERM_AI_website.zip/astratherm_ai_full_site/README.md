# ASTRATHERM AI

A responsive aerospace-themed website with your supplied ASTRATHERM logo, an AI chat interface, image upload/paste support, and a small Node.js backend.

## Run locally
1. Install Node.js 18 or newer.
2. Open this folder in a terminal.
3. Run `npm start`.
4. Open `http://localhost:3000`.

The homepage works without an API key, but live AI replies require one.

## Enable live AI replies
1. Create an API key in Google AI Studio: https://aistudio.google.com/app/apikey
2. Set `GEMINI_API_KEY` as an environment variable on your server/hosting provider. Never paste the key into `index.html` or share it publicly.
3. Optional: set `GEMINI_MODEL` to a model available to your API key. Default: `gemini-2.5-flash`.
4. Restart/redeploy the server.

The backend sends chat text and any attached image to Google's Gemini API. Images are not saved by this website. Review the AI provider's privacy and usage terms before using it.

## Deploy / 24-hour access
Deploy this Node.js project to a hosting provider that supports always-on Node.js apps and environment variables. A static-only host cannot run `server.js`. Free hosting tiers may sleep, have monthly quotas, or change availability, so 24/7 uptime and free AI usage cannot be guaranteed. Configure the API key as a server-side secret.

## Safety
ASTRA AI is configured for educational space science and high-level component explanations. It must not provide practical instructions, specifications, sourcing, assembly, testing, launch or propulsion guidance for real rockets or hazardous systems.

## Image support
Use the `+ IMG` button, or paste an image from the clipboard. PNG, JPEG and WebP are accepted; maximum 5 MB in the browser. The image is sent to the AI provider only when the message is submitted.


## Vision and sensor-intelligence prototype
- Image recognition is available through the ASTRA AI image attachment/paste chat feature (when the Gemini API is configured).
- The Sensor Intelligence section accepts manually entered demo temperature, humidity and vibration readings and sends them to ASTRA AI for educational comparison with user-provided reference values.
- This is not connected to physical sensors and is not a validated predictive or safety-monitoring system. Live hardware integration would require compatible sensors, a trusted data feed, testing and appropriate adult/professional oversight.


## Sensory and thermal recognition additions
- Sensory recognition demo: manually entered temperature, humidity and vibration readings are sent to ASTRA for educational comparison with user-provided reference values. No physical sensors are connected.
- Thermal recognition: users can upload a PNG, JPG or WEBP thermal-camera image (up to 5 MB) for qualitative analysis of visible relative hot/cold regions. Exact temperatures are not inferred unless a readable calibrated scale or measurement labels are visible.
- Both features use the existing `/api/chat` endpoint and require the private `GEMINI_API_KEY` environment variable on the server.
- These prototypes are not validated prediction, diagnostic, inspection or safety systems.
